// Search 
function searchTable() {
    var input = document.getElementById("searchInput");
    var filter = input.value.toUpperCase();
    var table = document.getElementById("dataTable");
    var tr = table.getElementsByTagName("tr");

    for (var i = 1; i < tr.length; i++) {
        tr[i].style.display = "none";
        var td = tr[i].getElementsByTagName("td");
        for (var j = 0; j < td.length; j++) {
            if (td[j]) {
                if (td[j].innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                    break;
                }
            }
        }
    }
}
$(document).ready(function() {
    $('#example').DataTable({
        "paging": true,
        "searching": true,
        "ordering": true
    });
});

// Pagination 
var currentPage = 1;
var rowsPerPage = 5;

function displayTablePage(page) {
    var table = document.getElementById("dataTable");
    var tr = table.getElementsByTagName("tr");
    var totalPages = Math.ceil((tr.length - 1) / rowsPerPage);

    currentPage = page;
    if (page < 1) currentPage = 1;
    if (page > totalPages) currentPage = totalPages;

    for (var i = 1; i < tr.length; i++) {
        tr[i].style.display = "none";
    }

    for (var i = (currentPage - 1) * rowsPerPage + 1; i <= currentPage * rowsPerPage && i < tr.length; i++) {
        tr[i].style.display = "";
    }

    var pagination = document.getElementById("pagination");
    pagination.innerHTML = "";

    for (var i = 1; i <= totalPages; i++) {
        pagination.innerHTML += `<button onclick="displayTablePage(${i})" style="margin: 2px;">${i}</button>`;
    }
}

displayTablePage(currentPage);
